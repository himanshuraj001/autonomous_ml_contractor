import os
import pandas as pd
import numpy as np
import xgboost as xgb
import joblib
from sklearn.model_selection import KFold
from sklearn.preprocessing import LabelEncoder
from sklearn.metrics import mean_squared_error
from sklearn.compose import ColumnTransformer
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import StandardScaler, OneHotEncoder

# Configuration
DATA_ROOT = "/kaggle/input/datasets/anmolkumar/house-price-prediction-challenge"
CHECKPOINT_DIR = "/kaggle/working/autonomous_ml/checkpoints"
os.makedirs(CHECKPOINT_DIR, exist_ok=True)

# Load Data
train_df = pd.read_csv(f"{DATA_ROOT}/train.csv")
test_df = pd.read_csv(f"{DATA_ROOT}/test.csv")

# Preprocessing Functions
def extract_city(address):
    parts = address.split(',')
    return parts[-1].strip() if len(parts) > 0 else 'Unknown'

def preprocess_data(df):
    df = df.copy()
    df['CITY'] = df['ADDRESS'].apply(extract_city)
    df = df.drop(columns=['ADDRESS'])
    return df

train_df = preprocess_data(train_df)
test_df = preprocess_data(test_df)

# Targets and Features
target_col = 'TARGET(PRICE_IN_LACS)'
y = np.log1p(train_df[target_col])
X = train_df.drop(columns=[target_col, 'POSTED_BY', 'READY_TO_MOVE'])

# Identify column types
cat_features = ['BHK_OR_RK', 'CITY']
num_features = ['UNDER_CONSTRUCTION', 'RERA', 'BHK_NO.', 'SQUARE_FT', 'RESALE', 'LONGITUDE', 'LATITUDE']

# Preprocessor
preprocessor = ColumnTransformer(
    transformers=[
        ('num', StandardScaler(), num_features),
        ('cat', OneHotEncoder(handle_unknown='ignore'), cat_features)
    ])

# Model Definition
model = xgb.XGBRegressor(
    n_estimators=1000,
    learning_rate=0.05,
    max_depth=6,
    subsample=0.8,
    colsample_bytree=0.8,
    reg_alpha=0.1,
    objective='reg:squarederror',
    tree_method='hist',
    n_jobs=-1
)

pipeline = Pipeline([
    ('preprocessor', preprocessor),
    ('model', model)
])

# Training Strategy (5-Fold CV)
kf = KFold(n_splits=5, shuffle=True, random_state=42)
rmse_scores = []

for fold, (train_idx, val_idx) in enumerate(kf.split(X, y)):
    X_train, X_val = X.iloc[train_idx], X.iloc[val_idx]
    y_train, y_val = y.iloc[train_idx], y.iloc[val_idx]
    
    pipeline.fit(X_train, y_train)
    
    val_preds = pipeline.predict(X_val)
    score = np.sqrt(mean_squared_error(y_val, val_preds))
    rmse_scores.append(score)
    
    print(f"Fold {fold+1} RMSE: {score:.4f}")
    joblib.dump(pipeline, f"{CHECKPOINT_DIR}/model_fold_{fold+1}.pkl")

print(f"Average RMSE: {np.mean(rmse_scores):.4f}")

# Final inference
test_preds = np.expm1(pipeline.predict(test_df[X.columns]))
submission = pd.DataFrame({target_col: test_preds})
submission.to_csv("/kaggle/working/submission.csv", index=False)
print("Submission saved to /kaggle/working/submission.csv")