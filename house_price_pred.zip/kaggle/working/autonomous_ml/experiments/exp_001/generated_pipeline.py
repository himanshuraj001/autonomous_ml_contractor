import os
import pandas as pd
import numpy as np
import xgboost as xgb
import joblib
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler, OneHotEncoder
from sklearn.metrics import mean_squared_error
from sklearn.compose import ColumnTransformer
from sklearn.pipeline import Pipeline
from sklearn.impute import SimpleImputer

# Configuration
DATA_ROOT = "/kaggle/input/datasets/anmolkumar/house-price-prediction-challenge"
CHECKPOINT_DIR = "/kaggle/working/autonomous_ml/checkpoints"
os.makedirs(CHECKPOINT_DIR, exist_ok=True)

# Load data
train_df = pd.read_csv(os.path.join(DATA_ROOT, "train.csv"))
test_df = pd.read_csv(os.path.join(DATA_ROOT, "test.csv"))

target_col = 'TARGET(PRICE_IN_LACS)'
numeric_features = ['UNDER_CONSTRUCTION', 'RERA', 'BHK_NO.', 'SQUARE_FT', 'RESALE', 'LONGITUDE', 'LATITUDE']
categorical_features = ['POSTED_BY', 'BHK_OR_RK', 'ADDRESS']

# Define features and target
X = train_df.drop(columns=[target_col, 'READY_TO_MOVE'])
y = train_df[target_col]

# Split data
X_train, X_val, y_train, y_val = train_test_split(X, y, test_size=0.2, random_state=42)

# Preprocessing Pipeline
numeric_transformer = Pipeline(steps=[
    ('imputer', SimpleImputer(strategy='median')),
    ('scaler', StandardScaler())
])

categorical_transformer = Pipeline(steps=[
    ('imputer', SimpleImputer(strategy='constant', fill_value='missing')),
    ('onehot', OneHotEncoder(handle_unknown='ignore', sparse_output=False))
])

preprocessor = ColumnTransformer(
    transformers=[
        ('num', numeric_transformer, numeric_features),
        ('cat', categorical_transformer, categorical_features)
    ])

# Fit preprocessor
X_train_transformed = preprocessor.fit_transform(X_train)
X_val_transformed = preprocessor.transform(X_val)

# Model initialization with early_stopping_rounds in constructor
regressor = xgb.XGBRegressor(
    n_estimators=1000,
    learning_rate=0.1,
    max_depth=7,
    tree_method='hist',
    n_jobs=-1,
    early_stopping_rounds=50 
)

# Fit regressor
regressor.fit(
    X_train_transformed, y_train,
    eval_set=[(X_val_transformed, y_val)],
    verbose=False
)

# Create final inference pipeline
model = Pipeline(steps=[
    ('preprocessor', preprocessor),
    ('regressor', regressor)
])

# Evaluation
preds = model.predict(X_val)
rmse = np.sqrt(mean_squared_error(y_val, preds))
print(f"Validation RMSE: {rmse:.4f}")

# Save Model
model_path = os.path.join(CHECKPOINT_DIR, "best_model.joblib")
joblib.dump(model, model_path)

# Generate submission
test_preds = model.predict(test_df.drop(columns=['READY_TO_MOVE']))
submission = pd.DataFrame({target_col: test_preds})
submission.to_csv("/kaggle/working/submission.csv", index=False)

print("Training complete. Model saved and submission generated.")