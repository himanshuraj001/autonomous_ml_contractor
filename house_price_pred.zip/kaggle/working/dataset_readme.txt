# DATASET README

## DATASET OVERVIEW

- Root Path: /kaggle/input/datasets/anmolkumar/house-price-prediction-challenge
- Total Files: 3
- Total Directories: 1

## FILE TYPE DISTRIBUTION

- .csv: 6

## CSV FILE ANALYSIS

### sample_submission.csv

- Path: /kaggle/input/datasets/anmolkumar/house-price-prediction-challenge/sample_submission.csv
- Semantic Guess: tabular_or_classification_csv
- Target Column Guess: TARGET(PRICE_IN_LACS)
- Shape: [68720, 1]

#### Column Roles
- label_columns: ['TARGET(PRICE_IN_LACS)']

#### Sample Rows

{
  "TARGET(PRICE_IN_LACS)": 0.0
}

{
  "TARGET(PRICE_IN_LACS)": 0.0
}

{
  "TARGET(PRICE_IN_LACS)": 0.0
}

### train.csv

- Path: /kaggle/input/datasets/anmolkumar/house-price-prediction-challenge/train.csv
- Semantic Guess: tabular_or_classification_csv
- Target Column Guess: POSTED_BY
- Shape: [29451, 12]

#### Column Roles
- label_columns: ['POSTED_BY', 'READY_TO_MOVE', 'TARGET(PRICE_IN_LACS)']
- numeric_columns: ['UNDER_CONSTRUCTION', 'RERA', 'BHK_NO.', 'SQUARE_FT', 'RESALE', 'LONGITUDE', 'LATITUDE']
- categorical_columns: ['BHK_OR_RK', 'ADDRESS']

#### Sample Rows

{
  "POSTED_BY": "Owner",
  "UNDER_CONSTRUCTION": 0,
  "RERA": 0,
  "BHK_NO.": 2,
  "BHK_OR_RK": "BHK",
  "SQUARE_FT": 1300.236407,
  "READY_TO_MOVE": 1,
  "RESALE": 1,
  "ADDRESS": "Ksfc Layout,Bangalore",
  "LONGITUDE": 12.96991,
  "LATITUDE": 77.59796,
  "TARGET(PRICE_IN_LACS)": 55.0
}

{
  "POSTED_BY": "Dealer",
  "UNDER_CONSTRUCTION": 0,
  "RERA": 0,
  "BHK_NO.": 2,
  "BHK_OR_RK": "BHK",
  "SQUARE_FT": 1275.0,
  "READY_TO_MOVE": 1,
  "RESALE": 1,
  "ADDRESS": "Vishweshwara Nagar,Mysore",
  "LONGITUDE": 12.274538,
  "LATITUDE": 76.644605,
  "TARGET(PRICE_IN_LACS)": 51.0
}

{
  "POSTED_BY": "Owner",
  "UNDER_CONSTRUCTION": 0,
  "RERA": 0,
  "BHK_NO.": 2,
  "BHK_OR_RK": "BHK",
  "SQUARE_FT": 933.1597222,
  "READY_TO_MOVE": 1,
  "RESALE": 1,
  "ADDRESS": "Jigani,Bangalore",
  "LONGITUDE": 12.778033,
  "LATITUDE": 77.632191,
  "TARGET(PRICE_IN_LACS)": 43.0
}

### test.csv

- Path: /kaggle/input/datasets/anmolkumar/house-price-prediction-challenge/test.csv
- Semantic Guess: tabular_or_classification_csv
- Target Column Guess: POSTED_BY
- Shape: [68720, 11]

#### Column Roles
- label_columns: ['POSTED_BY', 'READY_TO_MOVE']
- numeric_columns: ['UNDER_CONSTRUCTION', 'RERA', 'BHK_NO.', 'SQUARE_FT', 'RESALE', 'LONGITUDE', 'LATITUDE']
- categorical_columns: ['BHK_OR_RK', 'ADDRESS']

#### Sample Rows

{
  "POSTED_BY": "Owner",
  "UNDER_CONSTRUCTION": 0,
  "RERA": 0,
  "BHK_NO.": 1,
  "BHK_OR_RK": "BHK",
  "SQUARE_FT": 545.1713396,
  "READY_TO_MOVE": 1,
  "RESALE": 1,
  "ADDRESS": "Kamrej,Surat",
  "LONGITUDE": 21.262,
  "LATITUDE": 73.0477
}

{
  "POSTED_BY": "Dealer",
  "UNDER_CONSTRUCTION": 1,
  "RERA": 1,
  "BHK_NO.": 2,
  "BHK_OR_RK": "BHK",
  "SQUARE_FT": 800.0,
  "READY_TO_MOVE": 0,
  "RESALE": 0,
  "ADDRESS": "Panvel,Lalitpur",
  "LONGITUDE": 18.966114,
  "LATITUDE": 73.148278
}

{
  "POSTED_BY": "Dealer",
  "UNDER_CONSTRUCTION": 0,
  "RERA": 0,
  "BHK_NO.": 2,
  "BHK_OR_RK": "BHK",
  "SQUARE_FT": 1257.0965130000002,
  "READY_TO_MOVE": 1,
  "RESALE": 1,
  "ADDRESS": "New Town,Kolkata",
  "LONGITUDE": 22.5922,
  "LATITUDE": 88.484911
}

## IMPORTANT FILES

- /kaggle/input/datasets/anmolkumar/house-price-prediction-challenge/sample_submission.csv
- /kaggle/input/datasets/anmolkumar/house-price-prediction-challenge/train.csv
- /kaggle/input/datasets/anmolkumar/house-price-prediction-challenge/test.csv

## DATASET STRUCTURE TREE

 house-price-prediction-challenge
   sample_submission.csv
   train.csv
   test.csv


## CODER AGENT INSTRUCTIONS


Use this dataset information carefully.

Important Guidelines:
- Use correct dataset root paths.
- Use CSV annotation files if available.
- Use detected image columns correctly.
- Use target column guesses carefully.
- Join image paths relative to dataset root.
- Handle missing paths gracefully.
- Use train-validation split.
- Infer task type from semantic analysis.
- Use PyTorch best practices.
- Use mixed precision if GPU available.
